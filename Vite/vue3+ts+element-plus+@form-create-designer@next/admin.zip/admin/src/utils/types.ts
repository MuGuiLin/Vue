interface iAllTypes {
  ['key']: any;
}

export interface IScrollIntoVies extends iAllTypes {
  block: string;
  behavior: string;
}
