export enum PageEnum {
  BASE_HOME = "/",

  ERROR_PAGE = "/exception",
}
