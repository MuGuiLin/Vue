<script setup lang="ts" name="analysis">
import { ref } from "vue";
</script>

<template>
  <el-main class="analysis">

  </el-main>
</template>

<style scoped lang="less">
.analysis {
}
</style>