<script setup lang="ts" name="analysisEdit">
import { ref } from "vue";
</script>

<template>
  <el-main class="analysis-edit">

  </el-main>
</template>

<style scoped lang="less">
.analysis-edit {
}
</style>